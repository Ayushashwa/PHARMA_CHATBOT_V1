const form = document.getElementById("chat-form");
const messageInput = document.getElementById("message");
const chatLog = document.getElementById("chat-log");
const statusEl = document.getElementById("status");
const kpiContent = document.getElementById("kpi-content");
const kpiMonthSelect = document.getElementById("kpi-month");
const coverageContent = document.getElementById("coverage-content");
const efficiencyContent = document.getElementById("efficiency-content");
const regionTable = document.getElementById("region-table");
const ecosystemTable = document.getElementById("ecosystem-table");
const kpiDictionary = document.getElementById("kpi-dictionary");
const kpiDictionaryContent = document.getElementById("kpi-dictionary-content");

function appendMessage(role, text, source) {
  const message = document.createElement("div");
  message.className = `message ${role}`;

  const meta = document.createElement("div");
  meta.className = "meta";
  meta.textContent = role === "user" ? "You" : `Bot (${source})`;

  const body = document.createElement("div");
  body.className = "body";
  body.textContent = text;

  message.appendChild(meta);
  message.appendChild(body);
  chatLog.appendChild(message);
  chatLog.scrollTop = chatLog.scrollHeight;
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const message = messageInput.value.trim();
  if (!message) return;
  await sendMessage(message);
});

async function sendMessage(message) {
  appendMessage("user", message, "");
  messageInput.value = "";
  statusEl.textContent = "Sending...";

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message }),
    });

    const data = await response.json();
    appendMessage("assistant", data.answer || "No response", data.source || "llm");
  } catch (error) {
    appendMessage("assistant", "Network error. Please try again.", "client");
  } finally {
    statusEl.textContent = "";
  }
}

async function loadKpis() {
  if (!kpiContent) return;
  try {
    const response = await fetch("/api/summary");
    const summary = await response.json();
    if (!summary.loaded) {
      kpiContent.textContent = "Dataset not found. Add CSV to enable KPIs.";
      return;
    }

    const topRegions = summary.kpis.sales_per_mdm_by_region.slice(0, 5);
    const regionItems = topRegions
      .map(
        (item) =>
          `<li>${item.region}: ${item.sales_per_mdm.toFixed(2)}</li>`
      )
      .join("");

    kpiContent.innerHTML = `
      <div><strong>Rows:</strong> ${summary.rows}</div>
      <div><strong>Unique MDM:</strong> ${summary.unique_mdm}</div>
      <div><strong>Months:</strong> ${summary.months.min} to ${summary.months.max}</div>
      <div><strong>Total Sales (trx):</strong> ${summary.kpis.sales_total.toFixed(0)}</div>
      <div><strong>Total Calls:</strong> ${summary.totals.calls.toFixed(0)}</div>
      <div><strong>Sales per MDM (overall):</strong> ${summary.kpis.sales_per_mdm_overall.toFixed(2)}</div>
      <div><strong>Top Regions by Sales per MDM:</strong></div>
      <ul class="kpi-list">${regionItems}</ul>
    `;
  } catch (error) {
    kpiContent.textContent = "Could not load KPIs.";
  }
}

loadKpis();

function renderCoverage(kpi) {
  if (!coverageContent) return;
  if (!kpi.month) {
    coverageContent.textContent = "Coverage data not available.";
    return;
  }
  coverageContent.innerHTML = `
    <div><strong>Month:</strong> ${kpi.month}</div>
    <div><strong>Total MDM:</strong> ${kpi.total_mdm}</div>
    <div><strong>Reached MDM:</strong> ${kpi.reached_mdm}</div>
    <div><strong>Not Reached MDM:</strong> ${kpi.not_reached_mdm}</div>
    <div><strong>Reach %:</strong> ${kpi.reach_percent.toFixed(2)}%</div>
    <div><strong>Zero Call %:</strong> ${kpi.zero_call_percent.toFixed(2)}%</div>
  `;
}

function renderEfficiency(kpi) {
  if (!efficiencyContent) return;
  if (!kpi.month) {
    efficiencyContent.textContent = "Efficiency data not available.";
    return;
  }
  efficiencyContent.innerHTML = `
    <div><strong>Month:</strong> ${kpi.month}</div>
    <div><strong>Total Sales:</strong> ${kpi.total_sales.toFixed(0)}</div>
    <div><strong>Total Calls:</strong> ${kpi.total_calls.toFixed(0)}</div>
    <div><strong>Sales per Call:</strong> ${kpi.sales_per_call.toFixed(2)}</div>
    <div><strong>Sales per Reached MDM:</strong> ${kpi.sales_per_reached_mdm.toFixed(2)}</div>
    <div><strong>Calls per Reached MDM:</strong> ${kpi.calls_per_reached_mdm.toFixed(2)}</div>
  `;
}

function renderTable(container, rows, labelKey) {
  if (!container) return;
  if (!rows || rows.length === 0) {
    container.textContent = "No data available for this month.";
    return;
  }
  const headers = `
    <tr>
      <th>${labelKey}</th>
      <th>Total MDM</th>
      <th>Reached MDM</th>
      <th>Total Sales</th>
      <th>Total Calls</th>
      <th>Sales/Call</th>
      <th>Sales/Reached MDM</th>
    </tr>
  `;
  const body = rows
    .map(
      (row) => `
      <tr>
        <td>${row[labelKey]}</td>
        <td>${row.total_mdm}</td>
        <td>${row.reached_mdm}</td>
        <td>${row.total_sales.toFixed(0)}</td>
        <td>${row.total_calls.toFixed(0)}</td>
        <td>${row.sales_per_call.toFixed(2)}</td>
        <td>${row.sales_per_reached_mdm.toFixed(2)}</td>
      </tr>
    `
    )
    .join("");
  container.innerHTML = `<table>${headers}${body}</table>`;
}

async function loadKpisForMonth(month) {
  try {
    const [coverageRes, efficiencyRes, regionRes, ecosystemRes] = await Promise.all([
      fetch(`/api/kpi/coverage?month=${encodeURIComponent(month)}`),
      fetch(`/api/kpi/efficiency?month=${encodeURIComponent(month)}`),
      fetch(`/api/kpi/region?month=${encodeURIComponent(month)}`),
      fetch(`/api/kpi/ecosystem?month=${encodeURIComponent(month)}`),
    ]);

    const coverage = await coverageRes.json();
    const efficiency = await efficiencyRes.json();
    const regionRows = await regionRes.json();
    const ecosystemRows = await ecosystemRes.json();

    renderCoverage(coverage);
    renderEfficiency(efficiency);
    renderTable(regionTable, regionRows, "region");
    renderTable(ecosystemTable, ecosystemRows, "ecosystem");
  } catch (error) {
    if (coverageContent) coverageContent.textContent = "Could not load coverage KPIs.";
    if (efficiencyContent) efficiencyContent.textContent = "Could not load efficiency KPIs.";
    if (regionTable) regionTable.textContent = "Could not load region KPIs.";
    if (ecosystemTable) ecosystemTable.textContent = "Could not load ecosystem KPIs.";
  }
}

async function loadKpiMonths() {
  if (!kpiMonthSelect) return;
  try {
    const response = await fetch("/api/reach/all");
    const data = await response.json();
    if (!Array.isArray(data) || data.length === 0) {
      if (coverageContent) {
        coverageContent.textContent = "Dataset not found. Add CSV to enable KPIs.";
      }
      return;
    }

    kpiMonthSelect.innerHTML = "";
    data.forEach((item) => {
      const option = document.createElement("option");
      option.value = item.month;
      option.textContent = item.month;
      kpiMonthSelect.appendChild(option);
    });

    const latest = data[data.length - 1].month;
    kpiMonthSelect.value = latest;
    await loadKpisForMonth(latest);
  } catch (error) {
    if (coverageContent) {
      coverageContent.textContent = "Could not load KPI months.";
    }
  }
}

if (kpiMonthSelect) {
  kpiMonthSelect.addEventListener("change", (event) => {
    loadKpisForMonth(event.target.value);
  });
}

loadKpiMonths();

function renderKpiDictionary(catalog) {
  if (!kpiDictionaryContent) return;
  const sections = catalog.sections || [];
  if (!sections.length) {
    kpiDictionaryContent.textContent = "No KPI definitions found.";
    return;
  }

  const html = sections
    .map((section) => {
      const rows = (section.kpis || [])
        .map((kpi) => {
          const examples = (kpi.examples || [])
            .map(
              (example) =>
                `<button class="try-button" data-question="${example}">Try</button> ${example}`
            )
            .join("<br />");
          return `
            <tr>
              <td>${kpi.label}</td>
              <td>${kpi.definition}</td>
              <td>${kpi.formula}</td>
              <td>${kpi.unit}</td>
              <td>${examples}</td>
            </tr>
          `;
        })
        .join("");

      return `
        <section class="kpi-section">
          <h3>${section.title}</h3>
          <p>${section.description}</p>
          <div class="kpi-table-wrapper">
            <table class="kpi-table">
              <thead>
                <tr>
                  <th>KPI</th>
                  <th>Definition</th>
                  <th>Formula</th>
                  <th>Unit</th>
                  <th>Examples</th>
                </tr>
              </thead>
              <tbody>
                ${rows}
              </tbody>
            </table>
          </div>
        </section>
      `;
    })
    .join("");

  kpiDictionaryContent.innerHTML = html;
}

async function loadKpiDictionary() {
  if (!kpiDictionaryContent) return;
  try {
    const response = await fetch("/api/kpis");
    const catalog = await response.json();
    renderKpiDictionary(catalog);
  } catch (error) {
    kpiDictionaryContent.textContent = "Could not load KPI dictionary.";
  }
}

if (kpiDictionary) {
  kpiDictionary.addEventListener("toggle", () => {
    if (kpiDictionary.open && kpiDictionaryContent.dataset.loaded !== "true") {
      loadKpiDictionary();
      kpiDictionaryContent.dataset.loaded = "true";
    }
  });
}

document.addEventListener("click", (event) => {
  const target = event.target;
  if (!(target instanceof HTMLElement)) return;
  if (!target.classList.contains("try-button")) return;
  const question = target.getAttribute("data-question");
  if (!question) return;
  sendMessage(question);
});
