"""Lightweight data access helpers for the pharma CSV dataset."""

import os
from typing import Dict, List, Optional

import pandas as pd

_DATAFRAME: Optional[pd.DataFrame] = None


def load_dataset() -> Optional[pd.DataFrame]:
    """Load the dataset once and cache it in memory."""
    global _DATAFRAME
    if _DATAFRAME is not None:
        return _DATAFRAME

    dataset_path = os.getenv("DATASET_PATH", "./data/new_data.csv")
    if not os.path.exists(dataset_path):
        _DATAFRAME = None
        return None

    _DATAFRAME = pd.read_csv(dataset_path)
    for column in ("trx", "calls"):
        if column in _DATAFRAME.columns:
            _DATAFRAME[column] = pd.to_numeric(
                _DATAFRAME[column], errors="coerce"
            ).fillna(0)
            _DATAFRAME[column] = _DATAFRAME[column].clip(lower=0)
    return _DATAFRAME


def _ensure_dataframe() -> Optional[pd.DataFrame]:
    """Return the dataframe if available, otherwise None."""
    return load_dataset()


def get_available_months() -> List[str]:
    """Return sorted list of available months in the dataset."""
    df = _ensure_dataframe()
    if df is None:
        return []
    months = sorted(df["Month"].dropna().astype(str).unique().tolist())
    return months


def get_top_regions_by_trx(month: str, n: int = 5) -> Optional[List[Dict[str, object]]]:
    """Return top regions by trx for a given month."""
    df = _ensure_dataframe()
    if df is None:
        return None

    filtered = df[df["Month"] == month]
    if filtered.empty:
        return []

    grouped = (
        filtered.groupby("region", dropna=False)["trx"]
        .sum()
        .sort_values(ascending=False)
        .head(n)
    )

    return [{"region": region, "trx": int(trx)} for region, trx in grouped.items()]


def get_top_mdm_by_calls(month: str, n: int = 5) -> Optional[List[Dict[str, object]]]:
    """Return top MDM IDs by calls for a given month."""
    df = _ensure_dataframe()
    if df is None:
        return None

    filtered = df[df["Month"] == month]
    if filtered.empty:
        return []

    grouped = (
        filtered.groupby("MDM_ID", dropna=False)["calls"]
        .sum()
        .sort_values(ascending=False)
        .head(n)
    )

    return [{"mdm_id": mdm_id, "calls": int(calls)} for mdm_id, calls in grouped.items()]


def summarize_overall() -> Dict[str, object]:
    """Return overall dataset summary stats."""
    df = _ensure_dataframe()
    if df is None:
        return {
            "loaded": False,
            "rows": 0,
            "unique_mdm": 0,
            "months": {"min": None, "max": None},
            "totals": {"trx": 0.0, "calls": 0.0},
            "averages": {"trx_per_row": 0.0, "calls_per_row": 0.0},
            "kpis": {
                "sales_total": 0.0,
                "sales_per_mdm_overall": 0.0,
                "sales_per_mdm_by_region": [],
            },
        }

    months_series = df["Month"].dropna()
    month_min = None
    month_max = None
    if not months_series.empty:
        month_min = str(months_series.min())
        month_max = str(months_series.max())

    totals_trx = float(df["trx"].sum())
    totals_calls = float(df["calls"].sum())
    unique_mdm = int(df["MDM_ID"].nunique())
    sales_per_mdm_overall = totals_trx / unique_mdm if unique_mdm else 0.0

    return {
        "loaded": True,
        "rows": int(len(df)),
        "unique_mdm": unique_mdm,
        "months": {"min": month_min, "max": month_max},
        "totals": {"trx": totals_trx, "calls": totals_calls},
        "averages": {
            "trx_per_row": float(df["trx"].mean()),
            "calls_per_row": float(df["calls"].mean()),
        },
        "kpis": {
            "sales_total": totals_trx,
            "sales_per_mdm_overall": sales_per_mdm_overall,
            "sales_per_mdm_by_region": get_sales_per_mdm_by_region(),
        },
    }


def monthly_reach_kpi(month: str) -> Dict[str, object]:
    """Return reach KPIs for a given month."""
    df = _ensure_dataframe()
    if df is None:
        return {
            "loaded": False,
            "month": month,
            "total_mdm": 0,
            "reached_mdm": 0,
            "not_reached_mdm": 0,
            "reach_percent": 0.0,
        }

    filtered = df[df["Month"] == month]
    if filtered.empty:
        return {
            "loaded": False,
            "month": month,
            "total_mdm": 0,
            "reached_mdm": 0,
            "not_reached_mdm": 0,
            "reach_percent": 0.0,
        }

    total_mdm = int(filtered["MDM_ID"].nunique())
    reached_mdm = int(filtered[filtered["calls"] > 0]["MDM_ID"].nunique())
    not_reached_mdm = total_mdm - reached_mdm
    reach_percent = (reached_mdm / total_mdm * 100) if total_mdm else 0.0

    return {
        "loaded": True,
        "month": month,
        "total_mdm": total_mdm,
        "reached_mdm": reached_mdm,
        "not_reached_mdm": not_reached_mdm,
        "reach_percent": reach_percent,
    }


def monthly_reach_kpi_all() -> List[Dict[str, object]]:
    """Return reach KPIs for all months."""
    months = get_available_months()
    return [monthly_reach_kpi(month) for month in months]


def monthly_coverage_kpi(month: str) -> Dict[str, object]:
    """Return coverage KPIs for a given month."""
    df = _ensure_dataframe()
    if df is None:
        return {
            "month": month,
            "total_mdm": 0,
            "reached_mdm": 0,
            "not_reached_mdm": 0,
            "reach_percent": 0.0,
            "zero_call_percent": 0.0,
        }

    filtered = df[df["Month"] == month]
    if filtered.empty:
        return {
            "month": month,
            "total_mdm": 0,
            "reached_mdm": 0,
            "not_reached_mdm": 0,
            "reach_percent": 0.0,
            "zero_call_percent": 0.0,
        }

    total_mdm = int(filtered["MDM_ID"].nunique())
    reached_mdm = int(filtered[filtered["calls"] > 0]["MDM_ID"].nunique())
    not_reached_mdm = total_mdm - reached_mdm
    reach_percent = (reached_mdm / total_mdm * 100) if total_mdm else 0.0
    zero_call_percent = (not_reached_mdm / total_mdm * 100) if total_mdm else 0.0

    return {
        "month": month,
        "total_mdm": total_mdm,
        "reached_mdm": reached_mdm,
        "not_reached_mdm": not_reached_mdm,
        "reach_percent": reach_percent,
        "zero_call_percent": zero_call_percent,
    }


def monthly_sales_efficiency_kpi(month: str) -> Dict[str, object]:
    """Return sales efficiency KPIs for a given month."""
    df = _ensure_dataframe()
    if df is None:
        return {
            "month": month,
            "total_sales": 0.0,
            "total_calls": 0.0,
            "sales_per_call": 0.0,
            "sales_per_reached_mdm": 0.0,
            "calls_per_reached_mdm": 0.0,
        }

    filtered = df[df["Month"] == month]
    if filtered.empty:
        return {
            "month": month,
            "total_sales": 0.0,
            "total_calls": 0.0,
            "sales_per_call": 0.0,
            "sales_per_reached_mdm": 0.0,
            "calls_per_reached_mdm": 0.0,
        }

    total_sales = float(filtered["trx"].sum())
    total_calls = float(filtered["calls"].sum())
    reached_mdm = int(filtered[filtered["calls"] > 0]["MDM_ID"].nunique())

    sales_per_call = total_sales / total_calls if total_calls else 0.0
    sales_per_reached_mdm = total_sales / reached_mdm if reached_mdm else 0.0
    calls_per_reached_mdm = total_calls / reached_mdm if reached_mdm else 0.0

    return {
        "month": month,
        "total_sales": total_sales,
        "total_calls": total_calls,
        "sales_per_call": sales_per_call,
        "sales_per_reached_mdm": sales_per_reached_mdm,
        "calls_per_reached_mdm": calls_per_reached_mdm,
    }


def kpi_by_region(month: str) -> List[Dict[str, object]]:
    """Return KPI breakdown by region for a given month."""
    df = _ensure_dataframe()
    if df is None:
        return []

    filtered = df[df["Month"] == month]
    if filtered.empty:
        return []

    total_grouped = filtered.groupby("region").agg(
        total_mdm=("MDM_ID", "nunique"),
        total_sales=("trx", "sum"),
        total_calls=("calls", "sum"),
    )
    reached_grouped = (
        filtered[filtered["calls"] > 0]
        .groupby("region")["MDM_ID"]
        .nunique()
        .rename("reached_mdm")
    )
    grouped = total_grouped.join(reached_grouped, how="left").fillna(0).reset_index()

    grouped["sales_per_call"] = grouped.apply(
        lambda row: row["total_sales"] / row["total_calls"]
        if row["total_calls"]
        else 0.0,
        axis=1,
    )
    grouped["sales_per_reached_mdm"] = grouped.apply(
        lambda row: row["total_sales"] / row["reached_mdm"]
        if row["reached_mdm"]
        else 0.0,
        axis=1,
    )

    return [
        {
            "region": row["region"],
            "total_mdm": int(row["total_mdm"]),
            "reached_mdm": int(row["reached_mdm"]),
            "total_sales": float(row["total_sales"]),
            "total_calls": float(row["total_calls"]),
            "sales_per_call": float(row["sales_per_call"]),
            "sales_per_reached_mdm": float(row["sales_per_reached_mdm"]),
        }
        for _, row in grouped.iterrows()
    ]


def kpi_by_ecosystem(month: str) -> List[Dict[str, object]]:
    """Return KPI breakdown by ecosystem for a given month."""
    df = _ensure_dataframe()
    if df is None:
        return []

    filtered = df[df["Month"] == month]
    if filtered.empty:
        return []

    total_grouped = filtered.groupby("ecosystem").agg(
        total_mdm=("MDM_ID", "nunique"),
        total_sales=("trx", "sum"),
        total_calls=("calls", "sum"),
    )
    reached_grouped = (
        filtered[filtered["calls"] > 0]
        .groupby("ecosystem")["MDM_ID"]
        .nunique()
        .rename("reached_mdm")
    )
    grouped = total_grouped.join(reached_grouped, how="left").fillna(0).reset_index()

    grouped["sales_per_call"] = grouped.apply(
        lambda row: row["total_sales"] / row["total_calls"]
        if row["total_calls"]
        else 0.0,
        axis=1,
    )
    grouped["sales_per_reached_mdm"] = grouped.apply(
        lambda row: row["total_sales"] / row["reached_mdm"]
        if row["reached_mdm"]
        else 0.0,
        axis=1,
    )

    return [
        {
            "ecosystem": row["ecosystem"],
            "total_mdm": int(row["total_mdm"]),
            "reached_mdm": int(row["reached_mdm"]),
            "total_sales": float(row["total_sales"]),
            "total_calls": float(row["total_calls"]),
            "sales_per_call": float(row["sales_per_call"]),
            "sales_per_reached_mdm": float(row["sales_per_reached_mdm"]),
        }
        for _, row in grouped.iterrows()
    ]


def get_sales_per_mdm_by_region(
    month: Optional[str] = None, n: int = 10
) -> Optional[List[Dict[str, object]]]:
    """Return sales per MDM by region, optionally filtered by month."""
    df = _ensure_dataframe()
    if df is None:
        return None

    working = df
    if month:
        working = df[df["Month"] == month]

    if working.empty:
        return []

    grouped = (
        working.groupby("region")
        .agg(total_sales=("trx", "sum"), unique_mdm=("MDM_ID", "nunique"))
        .reset_index()
    )
    grouped["sales_per_mdm"] = grouped.apply(
        lambda row: row["total_sales"] / row["unique_mdm"]
        if row["unique_mdm"]
        else 0.0,
        axis=1,
    )
    grouped = grouped.sort_values("sales_per_mdm", ascending=False).head(n)

    return [
        {
            "region": row["region"],
            "unique_mdm": int(row["unique_mdm"]),
            "sales_total": float(row["total_sales"]),
            "sales_per_mdm": float(row["sales_per_mdm"]),
        }
        for _, row in grouped.iterrows()
    ]


def get_sales_per_mdm_overall(month: Optional[str] = None) -> Optional[float]:
    """Return sales per MDM for the whole dataset or a given month."""
    df = _ensure_dataframe()
    if df is None:
        return None

    working = df
    if month:
        working = df[df["Month"] == month]

    if working.empty:
        return 0.0

    total_sales = float(working["trx"].sum())
    unique_mdm = int(working["MDM_ID"].nunique())
    return total_sales / unique_mdm if unique_mdm else 0.0
