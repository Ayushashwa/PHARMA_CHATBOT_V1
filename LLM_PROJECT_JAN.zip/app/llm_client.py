"""Hugging Face Router client wrapper for chat completions."""

import os
from typing import Tuple

from openai import OpenAI


def get_llm_client() -> OpenAI:
    """Create an OpenAI-compatible client for Hugging Face Router."""
    return OpenAI(
        base_url="https://router.huggingface.co/v1",
        api_key=os.getenv("HF_TOKEN", ""),
    )


def chat_with_llm(system_prompt: str, user_message: str) -> Tuple[str, str]:
    """Send a chat request to the LLM and return (answer, error_message)."""
    client = get_llm_client()
    model_name = os.getenv("HF_MODEL", "meta-llama/Llama-4-Scout-17B-16E-Instruct")

    try:
        response = client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message},
            ],
        )
        answer = response.choices[0].message.content.strip()
        return answer, ""
    except Exception as exc:
        status_code = getattr(exc, "status_code", None)
        if status_code == 401:
            return "", "Invalid token"
        if status_code in (429, 503):
            return "", "Model busy / rate limited, retry in 10–20 seconds"
        return "", "Unexpected error while contacting the model"
