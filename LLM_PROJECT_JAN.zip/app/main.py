"""FastAPI app entrypoint and simple intent routing for the chatbot."""

import os
import re
from typing import Dict, Optional, Tuple

from dotenv import load_dotenv
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from app.data_layer import (
    get_available_months,
    get_top_mdm_by_calls,
    get_top_regions_by_trx,
    get_sales_per_mdm_by_region,
    get_sales_per_mdm_overall,
    kpi_by_ecosystem,
    kpi_by_region,
    monthly_coverage_kpi,
    monthly_sales_efficiency_kpi,
    monthly_reach_kpi,
    monthly_reach_kpi_all,
    summarize_overall,
)
from app.kpi_catalog import get_kpi_catalog, get_kpi_definition, list_kpi_titles
from app.llm_client import chat_with_llm
from app.prompts import SYSTEM_PROMPT

load_dotenv()

app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")

templates = Jinja2Templates(directory="templates")


@app.get("/", response_class=HTMLResponse)
def index(request: Request) -> HTMLResponse:
    """Serve the chat UI."""
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/api/summary")
def api_summary() -> JSONResponse:
    """Return overall dataset summary."""
    return JSONResponse(summarize_overall())


@app.get("/api/reach")
def api_reach(month: Optional[str] = None) -> JSONResponse:
    """Return reach KPIs for a single month."""
    available_months = get_available_months()
    selected_month = month or (available_months[-1] if available_months else "")
    return JSONResponse(monthly_reach_kpi(selected_month))


@app.get("/api/reach/all")
def api_reach_all() -> JSONResponse:
    """Return reach KPIs for all months."""
    return JSONResponse(monthly_reach_kpi_all())


@app.get("/api/kpi/coverage")
def api_kpi_coverage(month: Optional[str] = None) -> JSONResponse:
    """Return coverage KPIs for a single month."""
    available_months = get_available_months()
    selected_month = month or (available_months[-1] if available_months else "")
    return JSONResponse(monthly_coverage_kpi(selected_month))


@app.get("/api/kpi/efficiency")
def api_kpi_efficiency(month: Optional[str] = None) -> JSONResponse:
    """Return sales efficiency KPIs for a single month."""
    available_months = get_available_months()
    selected_month = month or (available_months[-1] if available_months else "")
    return JSONResponse(monthly_sales_efficiency_kpi(selected_month))


@app.get("/api/kpi/region")
def api_kpi_region(month: Optional[str] = None) -> JSONResponse:
    """Return region KPI breakdown for a single month."""
    available_months = get_available_months()
    selected_month = month or (available_months[-1] if available_months else "")
    return JSONResponse(kpi_by_region(selected_month))


@app.get("/api/kpi/ecosystem")
def api_kpi_ecosystem(month: Optional[str] = None) -> JSONResponse:
    """Return ecosystem KPI breakdown for a single month."""
    available_months = get_available_months()
    selected_month = month or (available_months[-1] if available_months else "")
    return JSONResponse(kpi_by_ecosystem(selected_month))


@app.get("/api/kpis")
def api_kpi_catalog() -> JSONResponse:
    """Return KPI catalog metadata."""
    return JSONResponse(get_kpi_catalog())


def parse_month_from_text(text: str) -> Optional[str]:
    """Parse a month from free text and return normalized YYYY-MM."""
    match = re.search(r"(20\d{2}[-/](0[1-9]|1[0-2]))", text)
    if match:
        return match.group(1).replace("/", "-")

    month_map = {
        "jan": "01",
        "january": "01",
        "feb": "02",
        "february": "02",
        "mar": "03",
        "march": "03",
        "apr": "04",
        "april": "04",
        "may": "05",
        "jun": "06",
        "june": "06",
        "jul": "07",
        "july": "07",
        "aug": "08",
        "august": "08",
        "sep": "09",
        "sept": "09",
        "september": "09",
        "oct": "10",
        "october": "10",
        "nov": "11",
        "november": "11",
        "dec": "12",
        "december": "12",
    }

    month_pattern = (
        r"(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|"
        r"jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t(?:ember)?)?|"
        r"oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)"
    )

    match = re.search(rf"{month_pattern}[-/_\s]+(20\d{{2}})", text, re.IGNORECASE)
    if match:
        month_name = match.group(1).lower()
        return f"{match.group(2)}-{month_map[month_name]}"

    match = re.search(rf"(20\d{{2}})[-/_\s]+{month_pattern}", text, re.IGNORECASE)
    if match:
        month_name = match.group(2).lower()
        return f"{match.group(1)}-{month_map[month_name]}"

    return None


def normalize_text(text: str) -> str:
    """Normalize text for intent matching."""
    return re.sub(r"\s+", " ", text.strip().lower())


def is_kpi_discovery(text: str) -> bool:
    """Detect KPI discovery/help queries."""
    tokens = [
        "what kpis are available",
        "list kpis",
        "show kpis",
        "kpi dictionary",
        "supported queries",
        "what can you do",
        "help",
        "commands",
    ]
    return any(token in text for token in tokens)


def is_kpi_definition_request(text: str) -> bool:
    """Detect KPI definition requests."""
    if "definition" in text or "define" in text:
        return True
    if text.startswith("explain "):
        return True
    if "what is " in text:
        return True
    return False


def extract_kpi_key_from_text(text: str) -> Optional[str]:
    """Map common phrases to KPI keys."""
    if "sales per reached mdm" in text:
        return "sales_per_reached_mdm_month"
    if "sales per call" in text:
        return "sales_per_call_month"
    if "calls per reached mdm" in text:
        return "calls_per_reached_mdm_month"
    if "reach percent" in text or "coverage" in text:
        return "reach_percent_month"
    if "zero call percent" in text or "zero-call percent" in text:
        return "zero_call_percent_month"
    if "sales per mdm" in text:
        return "sales_per_mdm_overall"
    return None


def is_unsupported_request(text: str) -> bool:
    """Detect requests we explicitly do not support."""
    unsupported_phrases = [
        "list the mdm",
        "list mdms",
        "show all mdm",
        "dump mdm",
        "show raw data",
        "export all rows",
        "give me all records",
    ]
    return any(phrase in text for phrase in unsupported_phrases)


def _route_to_data(message: str) -> Tuple[Optional[str], Optional[str], Optional[Dict[str, object]]]:
    """Try to answer using the dataset; return (answer, source, meta) or (None, None, None)."""
    lowered = message.lower()

    if "summary" in lowered or "overall" in lowered:
        summary = summarize_overall()
        if not summary.get("loaded", False):
            return "NOT FOUND", "data", {"reason": "dataset_not_loaded"}
        return (
            "Overall summary: "
            f"rows={summary['rows']}, "
            f"total_trx={summary['totals']['trx']:.0f}, "
            f"total_calls={summary['totals']['calls']:.0f}, "
            f"unique_mdm={summary['unique_mdm']}, "
            f"months={summary['months']['min']} to {summary['months']['max']}.",
            "data",
            {"summary": summary},
        )

    wants_top = "top" in lowered or "highest" in lowered
    wants_region = "region" in lowered
    wants_trx = "trx" in lowered
    wants_mdm = "mdm" in lowered
    wants_calls = "calls" in lowered
    wants_sales = "sales" in lowered
    wants_sales_per_mdm = "sales per mdm" in lowered
    wants_reached = "reached mdm" in lowered
    wants_not_reached = "not reached mdm" in lowered
    wants_reach = "mdm reach" in lowered or "mdm coverage" in lowered
    wants_coverage = "coverage" in lowered or "reach percent" in lowered
    wants_sales_per_call = "sales per call" in lowered
    wants_sales_per_reached = "sales per reached mdm" in lowered
    wants_region_efficiency = "region-wise" in lowered and "sales" in lowered
    wants_ecosystem_coverage = "ecosystem" in lowered and "coverage" in lowered

    month = parse_month_from_text(lowered)

    if wants_top and wants_region and wants_trx:
        available_months = get_available_months()
        if month and month not in available_months:
            if available_months:
                range_text = f"{available_months[0]} to {available_months[-1]}"
            else:
                range_text = "no data"
            return (
                f"NOT FOUND for month {month}. Available months: {range_text}.",
                "data",
                {"reason": "month_not_found"},
            )
        results = get_top_regions_by_trx(month or "") if month else []
        if results is None:
            return "NOT FOUND", "data", {"reason": "dataset_not_loaded"}
        if not results:
            return None, None, None
        lines = [f"{r['region']}: {r['trx']}" for r in results]
        return (
            f"Top regions by trx for {month}: " + ", ".join(lines),
            "data",
            {"month": month, "results": results},
        )

    if wants_top and wants_mdm and wants_calls:
        available_months = get_available_months()
        if month and month not in available_months:
            if available_months:
                range_text = f"{available_months[0]} to {available_months[-1]}"
            else:
                range_text = "no data"
            return (
                f"NOT FOUND for month {month}. Available months: {range_text}.",
                "data",
                {"reason": "month_not_found"},
            )
        results = get_top_mdm_by_calls(month or "") if month else []
        if results is None:
            return "NOT FOUND", "data", {"reason": "dataset_not_loaded"}
        if not results:
            return None, None, None
        lines = [f"{r['mdm_id']}: {r['calls']}" for r in results]
        return (
            f"Top MDMs by calls for {month}: " + ", ".join(lines),
            "data",
            {"month": month, "results": results},
        )

    if wants_sales_per_mdm and wants_region:
        available_months = get_available_months()
        if month and month not in available_months:
            if available_months:
                range_text = f"{available_months[0]} to {available_months[-1]}"
            else:
                range_text = "no data"
            return (
                f"NOT FOUND for month {month}. Available months: {range_text}.",
                "data",
                {"reason": "month_not_found"},
            )
        results = get_sales_per_mdm_by_region(month=month, n=5)
        if results is None:
            return "NOT FOUND", "data", {"reason": "dataset_not_loaded"}
        if not results:
            return None, None, None
        lines = [f"{r['region']}: {r['sales_per_mdm']:.2f}" for r in results]
        label = f" for {month}" if month else ""
        return (
            f"Sales per MDM by region{label}: " + ", ".join(lines),
            "data",
            {"month": month, "results": results},
        )

    if wants_sales_per_mdm and ("overall" in lowered or wants_sales):
        available_months = get_available_months()
        if month and month not in available_months:
            if available_months:
                range_text = f"{available_months[0]} to {available_months[-1]}"
            else:
                range_text = "no data"
            return (
                f"NOT FOUND for month {month}. Available months: {range_text}.",
                "data",
                {"reason": "month_not_found"},
            )
        value = get_sales_per_mdm_overall(month=month)
        if value is None:
            return "NOT FOUND", "data", {"reason": "dataset_not_loaded"}
        label = f" for {month}" if month else ""
        return (
            f"Sales per MDM overall{label}: {value:.2f}",
            "data",
            {"month": month, "sales_per_mdm_overall": value},
        )

    if wants_coverage or wants_reach:
        available_months = get_available_months()
        selected_month = month or (available_months[-1] if available_months else "")
        if month and month not in available_months:
            return "NOT FOUND", "data", {"reason": "month_not_found"}
        kpi = monthly_coverage_kpi(selected_month)
        return (
            (
                f"In {kpi['month']}, reach = {kpi['reached_mdm']} / "
                f"{kpi['total_mdm']} ({kpi['reach_percent']:.2f}%). "
                f"Not reached = {kpi['not_reached_mdm']}."
            ),
            "data",
            {"kpi": kpi},
        )

    if wants_sales_per_call or wants_sales_per_reached:
        available_months = get_available_months()
        selected_month = month or (available_months[-1] if available_months else "")
        if month and month not in available_months:
            return "NOT FOUND", "data", {"reason": "month_not_found"}
        kpi = monthly_sales_efficiency_kpi(selected_month)
        return (
            (
                f"In {kpi['month']}, sales per call = {kpi['sales_per_call']:.2f}, "
                f"sales per reached MDM = {kpi['sales_per_reached_mdm']:.2f}."
            ),
            "data",
            {"kpi": kpi},
        )

    if wants_region_efficiency:
        available_months = get_available_months()
        selected_month = month or (available_months[-1] if available_months else "")
        if month and month not in available_months:
            return "NOT FOUND", "data", {"reason": "month_not_found"}
        rows = kpi_by_region(selected_month)
        if not rows:
            return "NOT FOUND", "data", {"reason": "month_not_found"}
        lines = [
            f"{row['region']}: sales/call {row['sales_per_call']:.2f}"
            for row in rows[:5]
        ]
        return (
            f"Region-wise sales efficiency for {selected_month}: " + ", ".join(lines),
            "data",
            {"month": selected_month, "results": rows},
        )

    if wants_ecosystem_coverage:
        available_months = get_available_months()
        selected_month = month or (available_months[-1] if available_months else "")
        if month and month not in available_months:
            return "NOT FOUND", "data", {"reason": "month_not_found"}
        rows = kpi_by_ecosystem(selected_month)
        if not rows:
            return "NOT FOUND", "data", {"reason": "month_not_found"}
        lines = []
        for row in rows[:5]:
            reach_percent = (
                row["reached_mdm"] / row["total_mdm"] * 100
                if row["total_mdm"]
                else 0.0
            )
            lines.append(f"{row['ecosystem']}: {reach_percent:.2f}%")
        return (
            f"Ecosystem coverage for {selected_month}: " + ", ".join(lines),
            "data",
            {"month": selected_month, "results": rows},
        )

    if wants_reached or wants_not_reached or wants_reach:
        available_months = get_available_months()
        selected_month = month or (available_months[-1] if available_months else "")
        if month and month not in available_months:
            if available_months:
                range_text = f"{available_months[0]} to {available_months[-1]}"
            else:
                range_text = "no data"
            return (
                f"NOT FOUND for month {month}. Available months: {range_text}.",
                "data",
                {"reason": "month_not_found"},
            )
        kpi = monthly_reach_kpi(selected_month)
        if not kpi.get("loaded", False):
            if available_months:
                range_text = f"{available_months[0]} to {available_months[-1]}"
            else:
                range_text = "no data"
            return (
                f"NOT FOUND for month {selected_month}. Available months: {range_text}.",
                "data",
                {"reason": "month_not_found"},
            )
        return (
            (
                f"In {kpi['month']}, reached MDMs (calls>0) = "
                f"{kpi['reached_mdm']} / {kpi['total_mdm']} "
                f"({kpi['reach_percent']:.2f}%). "
                f"Not reached = {kpi['not_reached_mdm']}."
            ),
            "data",
            {"kpi": kpi},
        )

    return None, None, None


@app.post("/api/chat")
async def api_chat(payload: Dict[str, str]) -> JSONResponse:
    """Handle chat requests from the UI."""
    user_message = payload.get("message", "").strip()
    if not user_message:
        return JSONResponse({"answer": "Please enter a message.", "source": "llm"})

    normalized = normalize_text(user_message)

    if is_kpi_discovery(normalized):
        catalog = get_kpi_catalog()
        sections = catalog.get("sections", [])
        section_titles = [section.get("title", "") for section in sections]
        sample_kpis = list_kpi_titles()[:8]
        answer = (
            "KPI sections: "
            + ", ".join(section_titles)
            + ". Key KPIs include: "
            + ", ".join(sample_kpis)
            + ". Ask 'explain <kpi>' for definitions."
        )
        return JSONResponse({"answer": answer, "source": "data"})

    if is_kpi_definition_request(normalized):
        month = parse_month_from_text(normalized)
        wants_value = "in " in normalized or "for " in normalized or "what is " in normalized
        if month and wants_value:
            pass
        else:
            kpi_key = extract_kpi_key_from_text(normalized)
            if not kpi_key:
                return JSONResponse(
                    {
                        "answer": "NOT FOUND. Try: explain sales per call / explain reach percent / explain sales per reached mdm",
                        "source": "data",
                    }
                )
            definition = get_kpi_definition(kpi_key)
            if not definition:
                return JSONResponse(
                    {
                        "answer": "NOT FOUND. Try: explain sales per call / explain reach percent / explain sales per reached mdm",
                        "source": "data",
                    }
                )
            examples = definition.get("examples", [])[:2]
            answer = (
                f"{definition.get('label')}: {definition.get('definition')}. "
                f"Formula: {definition.get('formula')}. "
                f"Unit: {definition.get('unit')}. "
                f"Examples: {', '.join(examples)}"
            )
            return JSONResponse({"answer": answer, "source": "data"})

    if is_unsupported_request(normalized):
        answer = (
            "NOT SUPPORTED: This app does not list individual MDM IDs or dump raw records. "
            "Try: 'dataset summary', 'mdm coverage in 2024-01', "
            "'sales per call in 2025-12', 'top regions by trx in 2024-01'"
        )
        return JSONResponse({"answer": answer, "source": "data"})

    data_answer, source, meta = _route_to_data(user_message)
    if data_answer and source == "data":
        response_payload = {"answer": data_answer, "source": "data"}
        if meta:
            response_payload["meta"] = meta
        return JSONResponse(response_payload)

    answer, error_message = chat_with_llm(SYSTEM_PROMPT, user_message)
    if error_message:
        if error_message == "Invalid token":
            return JSONResponse(
                {
                    "answer": "LLM is not available (token missing/invalid). I can still answer data KPI questions. Try: 'dataset summary' or 'mdm coverage in jan 2024'.",
                    "source": "llm",
                }
            )
        return JSONResponse({"answer": error_message, "source": "llm"})

    return JSONResponse({"answer": answer, "source": "llm"})


if __name__ == "__main__":
    import uvicorn

    port = int(os.getenv("PORT", "8000"))
    uvicorn.run("app.main:app", host="0.0.0.0", port=port, reload=True)
