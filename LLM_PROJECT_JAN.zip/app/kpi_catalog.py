"""KPI catalog definitions for UI and API."""

from typing import Dict, List, Optional


def get_kpi_catalog() -> Dict[str, List[dict]]:
    """Return a structured catalog of KPI definitions."""
    return {
        "sections": [
            {
                "title": "Dataset KPIs",
                "description": "Sanity checks about dataset coverage and totals.",
                "kpis": [
                    {
                        "key": "rows",
                        "label": "Rows",
                        "definition": "Total number of records in the dataset.",
                        "formula": "count(rows)",
                        "unit": "rows",
                        "examples": ["dataset summary", "how many rows"],
                    },
                    {
                        "key": "unique_mdm",
                        "label": "Unique MDM",
                        "definition": "Distinct MDM_IDs across the dataset.",
                        "formula": "count(distinct MDM_ID)",
                        "unit": "count",
                        "examples": ["dataset summary", "unique mdm count"],
                    },
                    {
                        "key": "months_min",
                        "label": "Months Min",
                        "definition": "Earliest month in the dataset.",
                        "formula": "min(Month)",
                        "unit": "YYYY-MM",
                        "examples": ["dataset summary", "months range"],
                    },
                    {
                        "key": "months_max",
                        "label": "Months Max",
                        "definition": "Latest month in the dataset.",
                        "formula": "max(Month)",
                        "unit": "YYYY-MM",
                        "examples": ["dataset summary", "months range"],
                    },
                    {
                        "key": "total_sales_trx",
                        "label": "Total Sales (trx)",
                        "definition": "Total sales across the dataset (sales = trx).",
                        "formula": "sum(trx)",
                        "unit": "trx",
                        "examples": ["dataset summary", "total sales"],
                    },
                    {
                        "key": "total_calls",
                        "label": "Total Calls",
                        "definition": "Total calls across the dataset.",
                        "formula": "sum(calls)",
                        "unit": "calls",
                        "examples": ["dataset summary", "total calls"],
                    },
                    {
                        "key": "sales_per_mdm_overall",
                        "label": "Sales per MDM (overall)",
                        "definition": "Average sales per distinct MDM across the dataset.",
                        "formula": "sum(trx) / count(distinct MDM_ID)",
                        "unit": "trx/mdm",
                        "examples": ["sales per mdm overall", "sales per mdm overall in 2024-01"],
                    },
                    {
                        "key": "top_regions_by_sales_per_mdm",
                        "label": "Top Regions by Sales per MDM",
                        "definition": "Top regions by sales per MDM (overall unless a month is specified).",
                        "formula": "sum(trx by region) / count(distinct MDM_ID by region)",
                        "unit": "trx/mdm",
                        "examples": ["sales per mdm by region", "sales per mdm by region in 2024-01"],
                    },
                ],
            },
            {
                "title": "Coverage KPIs",
                "description": "Monthly coverage of MDMs based on calls > 0.",
                "kpis": [
                    {
                        "key": "total_mdm_month",
                        "label": "Total MDM (month)",
                        "definition": "Distinct MDM_IDs present in the month.",
                        "formula": "count(distinct MDM_ID where Month=YYYY-MM)",
                        "unit": "count",
                        "examples": ["coverage in jan 2024", "mdm coverage in 2025-12"],
                    },
                    {
                        "key": "reached_mdm_month",
                        "label": "Reached MDM (month)",
                        "definition": "Distinct MDM_IDs with calls > 0 in the month.",
                        "formula": "count(distinct MDM_ID where Month=YYYY-MM and calls>0)",
                        "unit": "count",
                        "examples": ["reached mdm in jan 2024", "reached mdm in 2024-01"],
                    },
                    {
                        "key": "not_reached_mdm_month",
                        "label": "Not Reached MDM (month)",
                        "definition": "MDMs present in the month but with zero calls.",
                        "formula": "total_mdm - reached_mdm",
                        "unit": "count",
                        "examples": ["not reached mdm in feb 2024", "not reached mdm in 2024-01"],
                    },
                    {
                        "key": "reach_percent_month",
                        "label": "Reach % (month)",
                        "definition": "Percent of monthly MDMs reached.",
                        "formula": "(reached_mdm / total_mdm) * 100",
                        "unit": "%",
                        "examples": ["reach percent in 2024-01", "coverage in jan 2024"],
                    },
                    {
                        "key": "zero_call_percent_month",
                        "label": "Zero Call % (month)",
                        "definition": "Percent of monthly MDMs with zero calls.",
                        "formula": "(not_reached_mdm / total_mdm) * 100",
                        "unit": "%",
                        "examples": ["coverage in 2024-01", "mdm coverage in feb 2024"],
                    },
                ],
            },
            {
                "title": "Sales Efficiency KPIs",
                "description": "Monthly sales efficiency and productivity metrics.",
                "kpis": [
                    {
                        "key": "total_sales_month",
                        "label": "Total Sales (month)",
                        "definition": "Total sales in the month.",
                        "formula": "sum(trx where Month=YYYY-MM)",
                        "unit": "trx",
                        "examples": ["sales per call in 2024-01", "sales per reached mdm in feb 2024"],
                    },
                    {
                        "key": "total_calls_month",
                        "label": "Total Calls (month)",
                        "definition": "Total calls in the month.",
                        "formula": "sum(calls where Month=YYYY-MM)",
                        "unit": "calls",
                        "examples": ["sales per call in 2024-01", "sales per reached mdm in feb 2024"],
                    },
                    {
                        "key": "sales_per_call_month",
                        "label": "Sales per Call (month)",
                        "definition": "Average sales per call in the month.",
                        "formula": "total_sales / total_calls",
                        "unit": "trx/call",
                        "examples": ["sales per call in 2024-01", "sales per call in jan 2024"],
                    },
                    {
                        "key": "sales_per_reached_mdm_month",
                        "label": "Sales per Reached MDM (month)",
                        "definition": "Average sales per reached MDM in the month.",
                        "formula": "total_sales / reached_mdm",
                        "unit": "trx/mdm",
                        "examples": ["sales per reached mdm in feb 2024", "sales per reached mdm in 2024-01"],
                    },
                    {
                        "key": "calls_per_reached_mdm_month",
                        "label": "Calls per Reached MDM (month)",
                        "definition": "Average calls per reached MDM in the month.",
                        "formula": "total_calls / reached_mdm",
                        "unit": "calls/mdm",
                        "examples": ["sales per reached mdm in feb 2024", "sales per call in 2024-01"],
                    },
                ],
            },
            {
                "title": "Region-wise KPIs",
                "description": "Monthly KPIs grouped by region.",
                "kpis": [
                    {
                        "key": "region_total_mdm",
                        "label": "Region Total MDM",
                        "definition": "Distinct MDMs in the region for the month.",
                        "formula": "count(distinct MDM_ID by region)",
                        "unit": "count",
                        "examples": ["region-wise sales efficiency in 2024-01"],
                    },
                    {
                        "key": "region_reached_mdm",
                        "label": "Region Reached MDM",
                        "definition": "Distinct MDMs with calls > 0 in the region.",
                        "formula": "count(distinct MDM_ID by region where calls>0)",
                        "unit": "count",
                        "examples": ["region-wise sales efficiency in 2024-01"],
                    },
                    {
                        "key": "region_total_sales",
                        "label": "Region Total Sales",
                        "definition": "Total sales in the region for the month.",
                        "formula": "sum(trx by region)",
                        "unit": "trx",
                        "examples": ["region-wise sales efficiency in 2024-01"],
                    },
                    {
                        "key": "region_total_calls",
                        "label": "Region Total Calls",
                        "definition": "Total calls in the region for the month.",
                        "formula": "sum(calls by region)",
                        "unit": "calls",
                        "examples": ["region-wise sales efficiency in 2024-01"],
                    },
                    {
                        "key": "region_sales_per_call",
                        "label": "Region Sales per Call",
                        "definition": "Average sales per call in the region.",
                        "formula": "region_total_sales / region_total_calls",
                        "unit": "trx/call",
                        "examples": ["region-wise sales efficiency in 2024-01"],
                    },
                    {
                        "key": "region_sales_per_reached_mdm",
                        "label": "Region Sales per Reached MDM",
                        "definition": "Average sales per reached MDM in the region.",
                        "formula": "region_total_sales / region_reached_mdm",
                        "unit": "trx/mdm",
                        "examples": ["region-wise sales efficiency in 2024-01"],
                    },
                ],
            },
            {
                "title": "Ecosystem-wise KPIs",
                "description": "Monthly KPIs grouped by ecosystem.",
                "kpis": [
                    {
                        "key": "ecosystem_total_mdm",
                        "label": "Ecosystem Total MDM",
                        "definition": "Distinct MDMs in the ecosystem for the month.",
                        "formula": "count(distinct MDM_ID by ecosystem)",
                        "unit": "count",
                        "examples": ["ecosystem coverage in 2025-12"],
                    },
                    {
                        "key": "ecosystem_reached_mdm",
                        "label": "Ecosystem Reached MDM",
                        "definition": "Distinct MDMs with calls > 0 in the ecosystem.",
                        "formula": "count(distinct MDM_ID by ecosystem where calls>0)",
                        "unit": "count",
                        "examples": ["ecosystem coverage in 2025-12"],
                    },
                    {
                        "key": "ecosystem_total_sales",
                        "label": "Ecosystem Total Sales",
                        "definition": "Total sales in the ecosystem for the month.",
                        "formula": "sum(trx by ecosystem)",
                        "unit": "trx",
                        "examples": ["ecosystem coverage in 2025-12"],
                    },
                    {
                        "key": "ecosystem_total_calls",
                        "label": "Ecosystem Total Calls",
                        "definition": "Total calls in the ecosystem for the month.",
                        "formula": "sum(calls by ecosystem)",
                        "unit": "calls",
                        "examples": ["ecosystem coverage in 2025-12"],
                    },
                    {
                        "key": "ecosystem_sales_per_call",
                        "label": "Ecosystem Sales per Call",
                        "definition": "Average sales per call in the ecosystem.",
                        "formula": "ecosystem_total_sales / ecosystem_total_calls",
                        "unit": "trx/call",
                        "examples": ["ecosystem coverage in 2025-12"],
                    },
                    {
                        "key": "ecosystem_sales_per_reached_mdm",
                        "label": "Ecosystem Sales per Reached MDM",
                        "definition": "Average sales per reached MDM in the ecosystem.",
                        "formula": "ecosystem_total_sales / ecosystem_reached_mdm",
                        "unit": "trx/mdm",
                        "examples": ["ecosystem coverage in 2025-12"],
                    },
                ],
            },
        ]
    }


def list_kpi_titles() -> List[str]:
    """Return a flat list of KPI labels for quick discovery."""
    catalog = get_kpi_catalog()
    titles: List[str] = []
    for section in catalog.get("sections", []):
        for kpi in section.get("kpis", []):
            if "label" in kpi:
                titles.append(kpi["label"])
    return titles


def get_kpi_definition(kpi_key: str) -> Optional[dict]:
    """Return definition details for a KPI key."""
    catalog = get_kpi_catalog()
    for section in catalog.get("sections", []):
        for kpi in section.get("kpis", []):
            if kpi.get("key") == kpi_key:
                return {
                    "label": kpi.get("label"),
                    "definition": kpi.get("definition"),
                    "formula": kpi.get("formula"),
                    "unit": kpi.get("unit"),
                    "examples": kpi.get("examples", []),
                }
    return None
